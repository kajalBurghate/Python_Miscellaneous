# print hello on screen

def main():
    print("Hello From Fun...")

if __name__ == "__main__":
    main()
    