# To check the input number is Even or Odd.

def ChkNum(Num):
    if(Num % 2 ==0):
        print("Number is Even.")
    else:
        print("Number is Odd.")

def main():
    print("Enter the Number:")
    Value1 = int(input())
    ChkNum(Value1)

if __name__ =="__main__":
    main()